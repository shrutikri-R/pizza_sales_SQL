-- 1) Retrieve the total number of orders placed.
select count(order_id) as total_orders from orders;

-- 2) calculate total revenue from pizza sales.
select
round(sum(order_details.quantity * pizzas.price) , 2) as total_sales
from order_details join pizzas
on pizzas.pizza_id = order_details.pizza_id





