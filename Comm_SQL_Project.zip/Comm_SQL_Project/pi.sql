SELECT * FROM pizzahut.pizzas;
CREATE TABLE orders(
order_id int not null,
order_date date not null,
order_time time not null,
primary key(order_id)  );